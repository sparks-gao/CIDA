from .training.train import main

def cli():
    main()

if __name__ == '__main__':
    main()
